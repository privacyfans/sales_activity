<?php
// Database configuration
define('DB_HOST', '151.106.119.252');
define('DB_USER', 'cbnb9676_cbnbandung_user');
define('DB_PASS', 'Arkan@199003');
define('DB_NAME', 'cbnb9676_cbnbandung');

// Session timeout setting (in seconds)
define('SESSION_TIMEOUT', 1800); // 30 minutes

// Other application settings can be added here
define('SITE_NAME', 'Admin Panel');
define('SITE_URL', 'https://cbnbandung.com');  // Replace with your actual domain
?>