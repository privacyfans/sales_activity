<?php
// File: notification_manager.php
// Class untuk mengelola notifikasi

class NotificationManager {
    private $conn;
    
    public function __construct($database_connection) {
        $this->conn = $database_connection;
    }
    
    // Check untuk sales visit yang jatuh tempo hari ini
    public function checkDueTodayNotifications() {
        $today = date('Y-m-d');
        
        // Query untuk mencari sales visit yang jatuh tempo hari ini
        $sql = "SELECT sv.*, u.id as user_id, u.full_name, u.role
                FROM sales_visit sv
                JOIN users u ON sv.created_by = u.id
                WHERE DATE(sv.jatuh_tempo_pemasangan) = ?
                AND sv.status IN ('Request', 'Connected')
                AND u.account_status = 'active'";
        
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $today);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $notifications_created = 0;
        
        while ($row = $result->fetch_assoc()) {
            // Cek apakah notifikasi untuk sales visit ini sudah dibuat hari ini
            if (!$this->isNotificationSent($row['id'], 'due_today', $today)) {
                $this->createNotification($row);
                $this->logNotification($row['id'], 'due_today', $today);
                $notifications_created++;
            }
        }
        
        return $notifications_created;
    }
    
    // Check untuk sales visit yang overdue
    public function checkOverdueNotifications() {
        $today = date('Y-m-d');
        
        $sql = "SELECT sv.*, u.id as user_id, u.full_name, u.role
                FROM sales_visit sv
                JOIN users u ON sv.created_by = u.id
                WHERE DATE(sv.jatuh_tempo_pemasangan) < ?
                AND sv.status IN ('Request')
                AND u.account_status = 'active'";
        
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $today);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $notifications_created = 0;
        
        while ($row = $result->fetch_assoc()) {
            if (!$this->isNotificationSent($row['id'], 'overdue', $today)) {
                $this->createOverdueNotification($row);
                $this->logNotification($row['id'], 'overdue', $today);
                $notifications_created++;
            }
        }
        
        return $notifications_created;
    }
    
    // Buat notifikasi untuk jatuh tempo hari ini
    private function createNotification($salesVisit) {
        $title = "Jatuh Tempo Pemasangan Hari Ini";
        $message = "Sales visit untuk {$salesVisit['nama']} (ID: {$salesVisit['id_pelanggan']}) jatuh tempo hari ini. Status: {$salesVisit['status']}";
        
        $sql = "INSERT INTO notifications (user_id, sales_visit_id, type, title, message) VALUES (?, ?, 'due_today', ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("iiss", $salesVisit['user_id'], $salesVisit['id'], $title, $message);
        $stmt->execute();
        
        // Kirim push notification jika user memiliki subscription
        $this->sendPushNotification($salesVisit['user_id'], $title, $message);
        
        // Kirim ke admin juga
        $this->notifyAdmins($salesVisit, $title, $message);
    }
    
    // Buat notifikasi untuk overdue
    private function createOverdueNotification($salesVisit) {
        $daysOverdue = (strtotime(date('Y-m-d')) - strtotime($salesVisit['jatuh_tempo_pemasangan'])) / 86400;
        $title = "Pemasangan Terlambat";
        $message = "Sales visit untuk {$salesVisit['nama']} (ID: {$salesVisit['id_pelanggan']}) sudah terlambat {$daysOverdue} hari. Segera follow up!";
        
        $sql = "INSERT INTO notifications (user_id, sales_visit_id, type, title, message) VALUES (?, ?, 'overdue', ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("iiss", $salesVisit['user_id'], $salesVisit['id'], $title, $message);
        $stmt->execute();
        
        $this->sendPushNotification($salesVisit['user_id'], $title, $message);
        $this->notifyAdmins($salesVisit, $title, $message);
    }
    
    // Notify semua admin
    private function notifyAdmins($salesVisit, $title, $message) {
        $sql = "SELECT id FROM users WHERE role = 'admin' AND account_status = 'active'";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while ($admin = $result->fetch_assoc()) {
            if ($admin['id'] != $salesVisit['user_id']) { // Jangan duplikasi jika sales adalah admin
                $adminMessage = "[Admin Alert] " . $message . " (Sales: {$salesVisit['full_name']})";
                
                $insertSql = "INSERT INTO notifications (user_id, sales_visit_id, type, title, message) VALUES (?, ?, 'due_today', ?, ?)";
                $insertStmt = $this->conn->prepare($insertSql);
                $insertStmt->bind_param("iiss", $admin['id'], $salesVisit['id'], $title, $adminMessage);
                $insertStmt->execute();
                
                $this->sendPushNotification($admin['id'], $title, $adminMessage);
            }
        }
    }
    
    // Kirim push notification
    private function sendPushNotification($userId, $title, $message) {
        // Get user's push subscriptions
        $sql = "SELECT * FROM push_subscriptions WHERE user_id = ? AND is_active = 1";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while ($subscription = $result->fetch_assoc()) {
            $this->sendWebPush($subscription, $title, $message);
        }
    }
    
    // Kirim web push notification
    private function sendWebPush($subscription, $title, $message) {
        // Implementasi web push menggunakan library seperti web-push-php
        // Untuk sekarang, kita log saja
        error_log("Sending push notification to user: $title - $message");
        
        // Jika menggunakan library web-push-php:
        /*
        $auth = array(
            'VAPID' => array(
                'subject' => 'mailto:admin@yoursite.com',
                'publicKey' => 'YOUR_VAPID_PUBLIC_KEY',
                'privateKey' => 'YOUR_VAPID_PRIVATE_KEY'
            )
        );
        
        $webPush = new WebPush($auth);
        
        $webPush->sendNotification(
            Subscription::create([
                'endpoint' => $subscription['endpoint'],
                'keys' => [
                    'p256dh' => $subscription['p256dh_key'],
                    'auth' => $subscription['auth_key']
                ]
            ]),
            json_encode([
                'title' => $title,
                'body' => $message,
                'icon' => '/favicon.ico',
                'url' => '/sales_visit.php'
            ])
        );
        */
    }
    
    // Cek apakah notifikasi sudah dikirim
    private function isNotificationSent($salesVisitId, $type, $date) {
        $sql = "SELECT id FROM notification_logs WHERE sales_visit_id = ? AND notification_type = ? AND sent_date = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("iss", $salesVisitId, $type, $date);
        $stmt->execute();
        $result = $stmt->get_result();
        
        return $result->num_rows > 0;
    }
    
    // Log notifikasi yang sudah dikirim
    private function logNotification($salesVisitId, $type, $date) {
        $sql = "INSERT INTO notification_logs (sales_visit_id, notification_type, sent_date) VALUES (?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("iss", $salesVisitId, $type, $date);
        $stmt->execute();
    }
    
    // Get notifikasi untuk user
    public function getUserNotifications($userId, $limit = 10, $unreadOnly = false) {
        $sql = "SELECT n.*, sv.nama as customer_name, sv.id_pelanggan
                FROM notifications n
                LEFT JOIN sales_visit sv ON n.sales_visit_id = sv.id
                WHERE n.user_id = ?";
        
        if ($unreadOnly) {
            $sql .= " AND n.is_read = 0";
        }
        
        $sql .= " ORDER BY n.created_at DESC LIMIT ?";
        
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ii", $userId, $limit);
        $stmt->execute();
        
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    // Mark notifikasi sebagai dibaca
    public function markAsRead($notificationId, $userId) {
        $sql = "UPDATE notifications SET is_read = 1, read_at = NOW() WHERE id = ? AND user_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ii", $notificationId, $userId);
        return $stmt->execute();
    }
    
    // Get jumlah notifikasi yang belum dibaca
    public function getUnreadCount($userId) {
        $sql = "SELECT COUNT(*) as unread_count FROM notifications WHERE user_id = ? AND is_read = 0";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        
        return $row['unread_count'];
    }
    
    // Bersihkan notifikasi lama (lebih dari 30 hari)
    public function cleanupOldNotifications() {
        $sql = "DELETE FROM notifications WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)";
        $stmt = $this->conn->prepare($sql);
        return $stmt->execute();
    }
}
?>